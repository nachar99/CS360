package com.example.sensormanager;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private SensorManager mySensorManager;
    private Sensor accelSensor;
    private TextView displayValues;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        displayValues = findViewById(R.id.sensorText);

        mySensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        if (mySensorManager != null) {
            accelSensor = mySensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        }

        if (accelSensor != null) {
            mySensorManager.registerListener(this, accelSensor, SensorManager.SENSOR_DELAY_NORMAL);
        } else {
            displayValues.setText("No Accelerometer in device");
        }
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        float accelX = sensorEvent.values[0];
        float accelY = sensorEvent.values[1];
        float accelZ = sensorEvent.values[2];

        String result = "Values:\nX: " + accelX + "\nY: " + accelY + "\nZ: " + accelZ;
        displayValues.setText(result);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Not used for this app
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mySensorManager != null) {
            mySensorManager.unregisterListener(this);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (accelSensor != null) {
            mySensorManager.registerListener(this, accelSensor, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }
}
