package com.example.Abdulrahman_AlNachar;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.TextView;
import android.view.View;
import android.widget.EditText;
import android.text.TextWatcher;
import android.text.Editable;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        EditText nameInput = findViewById(R.id.nameText);
        Button submitButton = findViewById(R.id.buttonSayHello);

        submitButton.setEnabled(false);

        nameInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence input, int startIndex, int removedCount, int afterCount) {}

            @Override
            public void onTextChanged(CharSequence input, int startIndex, int removedCount, int afterCount) {
                submitButton.setEnabled(!input.toString().isEmpty());
            }

            @Override
            public void afterTextChanged(Editable input) {}
        });



    }

    public void SayHello(View view) {
        EditText nameInput = findViewById(R.id.nameText);
        TextView greetMessage = findViewById(R.id.textGreeting);

        String name = nameInput.getText().toString();

        if (name.isEmpty()) {
            return;
        }

        greetMessage.setText("Hi " + name);
    }
}
