// This is the database class that handles storing inventory items per user
package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.List;
import java.util.ArrayList;

public class InventoryDatabase extends SQLiteOpenHelper {

    // DB name + version
    private static final String DATABASE_NAME = "InventoryItems.db";
    private static final int DATABASE_VERSION = 1;

    // table + column names
    public static final String TABLE_NAME = "inventory";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_NAME = "item_name";
    public static final String COLUMN_QUANTITY = "quantity";
    public static final String COLUMN_USER = "username"; // so we can tie items to a user

    public InventoryDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // create the inventory table with all needed columns
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_NAME + " TEXT NOT NULL, " +
                COLUMN_QUANTITY + " INTEGER DEFAULT 1, " +
                COLUMN_USER + " TEXT NOT NULL)"; // user column so each user has separate items
        db.execSQL(CREATE_TABLE);

        // default items are added per-user in code (not here)
    }

    // drop and recreate the table if we ever upgrade the schema
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // insert a new item for a specific user
    public boolean addItem(String name, int quantity, String username) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_QUANTITY, quantity);
        values.put(COLUMN_USER, username);
        long result = db.insert(TABLE_NAME, null, values);
        return result != -1; // return true if it was added successfully
    }

    // fetch all items that belong to the logged-in user
    public List<InventoryItem> getAllInventoryItems(String username) {
        List<InventoryItem> itemList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_NAME,
                null,
                COLUMN_USER + " = ?",
                new String[]{username},
                null, null, null
        );

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_QUANTITY));
                itemList.add(new InventoryItem(id, name, quantity));
            } while (cursor.moveToNext());
        }

        cursor.close();
        return itemList;
    }

    // update the quantity for a specific item ID
    public boolean updateQuantity(int id, int newQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_QUANTITY, newQuantity);
        int rows = db.update(TABLE_NAME, values, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
        return rows > 0;
    }

    // remove an item from the DB based on its ID
    public boolean deleteItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_NAME, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
        return rows > 0;
    }
}
