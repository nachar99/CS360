// This screen handles asking for SMS permission + phone input
package com.example.inventoryapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsPermissionActivity extends AppCompatActivity {

    // Permission request code constant
    private static final int SMS_PERMISSION_CODE = 100;

    // UI elements
    private Button btnGrant, btnSkip;
    private TextView permissionStatus, smsInfo;
    private EditText phoneInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sms_permission);

        // link UI
        btnGrant = findViewById(R.id.btnPermission);
        btnSkip = findViewById(R.id.btnSkip);
        permissionStatus = findViewById(R.id.permissionStatus);
        smsInfo = findViewById(R.id.smsInfo);
        phoneInput = findViewById(R.id.phoneInput);

        // show whether SMS permission is already granted
        checkPermissionStatus();

        // ask for permission if user taps Grant
        btnGrant.setEnabled(true);
        btnGrant.setOnClickListener(v -> requestSmsPermission());

        // go forward without SMS if they tap Skip
        btnSkip.setOnClickListener(v -> goToHome());
    }

    // checks if permission is granted, updates the label
    private void checkPermissionStatus() {
        boolean granted = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
        permissionStatus.setText("Permission Status: " + (granted ? "Granted" : "Not Granted"));
    }

    // if we don’t have permission yet, ask for it
    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            Toast.makeText(this, "Permission already granted", Toast.LENGTH_SHORT).show();
            goToHome();
        }
    }

    // this runs after the user responds to the permission popup
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
            }
            goToHome(); // regardless of what they chose, we keep going
        }
    }

    // takes user to the HomeActivity screen, passes username and saves phone
    private void goToHome() {
        String username = getIntent().getStringExtra("username");
        String number = phoneInput.getText().toString().trim();

        // save the number for later use
        getSharedPreferences("MyPrefs", MODE_PRIVATE)
                .edit()
                .putString("phone_number", number)
                .apply();

        // launch the home screen with the username
        Intent intent = new Intent(SmsPermissionActivity.this, HomeActivity.class);
        intent.putExtra("username", username);
        startActivity(intent);
        finish();
    }
}
