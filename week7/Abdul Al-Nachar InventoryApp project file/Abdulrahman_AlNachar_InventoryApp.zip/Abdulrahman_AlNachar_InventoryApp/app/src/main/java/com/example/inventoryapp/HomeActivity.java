// this is the main screen the user sees after logging in where they interact with their inventory.
package com.example.inventoryapp;

import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.app.AlertDialog;
import android.widget.EditText;
import android.widget.Toast;
import android.util.Log;

import android.telephony.SmsManager;
import android.Manifest;
import android.content.pm.PackageManager;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity {

    TextView welcomeText;
    GridLayout inventoryGrid;
    InventoryDatabase inventoryDb;
    List<InventoryItem> itemList = new ArrayList<>();
    int currentIndex = 0;
    String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // getting UI elements + DB ready
        welcomeText = findViewById(R.id.inventoryHeader);
        inventoryGrid = findViewById(R.id.inventoryGrid);
        inventoryDb = new InventoryDatabase(this);

        // grab the username from the login screen and personalize the greeting
        username = getIntent().getStringExtra("username");
        if (username != null) {
            welcomeText.setText("Hi " + username);
        }

        // fill in the default inventory if this user has nothing yet
        seedInventoryIfNeeded();

        // show items + enable the buttons
        itemList = inventoryDb.getAllInventoryItems(username);
        displayInventory();
        setupButtons();
    }

    // if this is the first time this user opens the app, we give them 15 default items
    private void seedInventoryIfNeeded() {
        List<InventoryItem> existing = inventoryDb.getAllInventoryItems(username);
        if (existing.isEmpty()) {
            for (int i = 1; i <= 15; i++) {
                inventoryDb.addItem("Item #" + i, 1, username); // default quantity = 1
            }
        }
    }

    private void displayInventory() {
        // clear and then repopulate the grid with current items
        inventoryGrid.removeAllViews();
        Resources res = getResources();

        for (int i = 0; i < itemList.size(); i++) {
            InventoryItem item = itemList.get(i);

            // make a little container to show this item’s name + quantity
            LinearLayout itemLayout = new LinearLayout(this);
            itemLayout.setOrientation(LinearLayout.VERTICAL);
            itemLayout.setPadding(8, 8, 8, 8);
            int bgColor = (i == currentIndex)
                    ? res.getColor(R.color.lighterAccentColor)
                    : res.getColor(R.color.accentColor);
            itemLayout.setBackgroundColor(bgColor);

            TextView nameView = new TextView(this);
            nameView.setText("Item: " + item.getName());
            nameView.setTypeface(null, Typeface.BOLD);
            nameView.setTextColor(res.getColor(R.color.primaryColor));

            TextView qtyView = new TextView(this);
            qtyView.setText("Quantity: " + item.getQuantity());
            qtyView.setTextColor(res.getColor(R.color.primaryColor));

            itemLayout.addView(nameView);
            itemLayout.addView(qtyView);

            GridLayout.LayoutParams params = new GridLayout.LayoutParams();
            params.width = 0;  // Let weight take control
            params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);  // Spread evenly
            params.setMargins(8, 8, 8, 8);
            itemLayout.setLayoutParams(params);


            final int index = i;

            // clicking an item makes it the "selected" one (for updating or deleting)
            itemLayout.setOnClickListener(v -> {
                currentIndex = index;
                refreshInventory();
            });

            inventoryGrid.addView(itemLayout);
        }
    }

    private void setupButtons() {
        // grab all 4 action buttons: + − ↑ ↓
        Button btnAdd = (Button) ((LinearLayout) findViewById(R.id.actionButtons)).getChildAt(0);
        Button btnRemove = (Button) ((LinearLayout) findViewById(R.id.actionButtons)).getChildAt(1);
        Button btnUp = (Button) ((LinearLayout) findViewById(R.id.actionButtons)).getChildAt(2);
        Button btnDown = (Button) ((LinearLayout) findViewById(R.id.actionButtons)).getChildAt(3);

        btnAdd.setOnClickListener(v -> {
            // pop up input box to name the new item
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("New Item Name");

            final EditText input = new EditText(this);
            input.setHint("Enter item name");
            builder.setView(input);

            builder.setPositiveButton("Add", (dialog, which) -> {
                String itemName = input.getText().toString().trim();

                // don’t let them submit empty names
                if (!itemName.isEmpty()) {
                    inventoryDb.addItem(itemName, 1, username); // ⬅️ quantity 1 + user
                    refreshInventory();
                    currentIndex = itemList.size(); // highlight last item
                } else {
                    Toast.makeText(this, "Item name can't be empty", Toast.LENGTH_SHORT).show();
                }
            });

            builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
            builder.show();
        });

        // remove the selected item from the list + DB
        btnRemove.setOnClickListener(v -> {
            if (!itemList.isEmpty()) {
                InventoryItem selected = itemList.get(currentIndex);
                inventoryDb.deleteItem(selected.getId());
                currentIndex = Math.max(0, currentIndex - 1);
                refreshInventory();
            }
        });

        // add 1 to the selected item’s quantity
        btnUp.setOnClickListener(v -> {
            if (!itemList.isEmpty()) {
                InventoryItem item = itemList.get(currentIndex);
                inventoryDb.updateQuantity(item.getId(), item.getQuantity() + 1);
                refreshInventory();
            }
        });

        // subtract 1 from quantity but don’t let it go below 0
        btnDown.setOnClickListener(v -> {
            if (!itemList.isEmpty()) {
                InventoryItem item = itemList.get(currentIndex);
                inventoryDb.updateQuantity(item.getId(), Math.max(0, item.getQuantity() - 1));
                refreshInventory();
            }
        });
    }

    private void refreshInventory() {
        // re-load everything from DB and repaint the grid
        itemList = inventoryDb.getAllInventoryItems(username);
        displayInventory();

        String number = getSharedPreferences("MyPrefs", MODE_PRIVATE)
                .getString("phone_number", null);

        // if user allowed SMS + gave a phone number, send alert for any out-of-stock item
        if (number != null && !number.isEmpty() &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                        == PackageManager.PERMISSION_GRANTED) {

            for (InventoryItem item : itemList) {
                if (item.getQuantity() == 0) {
                    try {
                        // for any 0-qty item, text the user to let them know
                        SmsManager smsManager = SmsManager.getDefault();
                        smsManager.sendTextMessage(number, null,
                                "Alert: " + item.getName() + " is out of stock!",
                                null, null);
                        // I checked in logcat that the sms was being sent
                        Log.d("SMS_TEST", "Sending SMS to " + number + " for " + item.getName());

                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(this, "SMS failed to send", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }
    }
}
