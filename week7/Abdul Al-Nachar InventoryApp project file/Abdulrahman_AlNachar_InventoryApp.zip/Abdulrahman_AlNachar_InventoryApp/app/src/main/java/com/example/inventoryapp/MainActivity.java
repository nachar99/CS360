// Main screen where the user can either log in or create a new account
package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // user input fields for login
    EditText textUsername, textPassword;
    // login and sign-up buttons
    Button btnLogin, btnCreateAccount;
    // database that handles login logic and storing user credentials
    AuthenticationDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // referencing all UI elements we’ll use
        textUsername = findViewById(R.id.textUsername);
        textPassword = findViewById(R.id.textPassword);
        btnLogin = findViewById(R.id.BtnLogin);
        btnCreateAccount = findViewById(R.id.BtnCreateAccount);

        db = new AuthenticationDatabase(this);
        // setting up the database helper to check credentials and create accounts


        btnLogin.setOnClickListener(new View.OnClickListener() {
            // login button logic: first we check if user filled in both fields
            @Override
            public void onClick(View view) {
                String username = textUsername.getText().toString().trim();
                String password = textPassword.getText().toString().trim();

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter username and password", Toast.LENGTH_SHORT).show();
                } else {
                    boolean isValid = db.validateLogin(username, password);
                    if (isValid) {
                        // valid credentials, so we move the user to the next screen (SMS permissions)
                        Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(MainActivity.this, SmsPermissionActivity.class);
                        intent.putExtra("username", username);
                        startActivity(intent);
                        finish();
                    } else {
                        // login failed – show error toast
                        Toast.makeText(MainActivity.this, "Invalid credentials", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        btnCreateAccount.setOnClickListener(new View.OnClickListener() {
            // sign-up logic: check if fields aren't empty
            @Override
            public void onClick(View view) {
                String username = textUsername.getText().toString().trim();
                String password = textPassword.getText().toString().trim();

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Username and password cannot be empty", Toast.LENGTH_SHORT).show();
                } else {
                    boolean exists = db.validateLogin(username, password);
                    if (!exists) {
                        // if account doesn't exist, try to create it
                        boolean inserted = db.insertUser(username, password);
                        if (inserted) {
                            // new account successfully created
                            Toast.makeText(MainActivity.this, "Account created successfully", Toast.LENGTH_SHORT).show();
                        } else {
                            // something went wrong while creating the account
                            Toast.makeText(MainActivity.this, "Error creating account", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        // user tried to create an account that already exists
                        Toast.makeText(MainActivity.this, "Account already exists", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
