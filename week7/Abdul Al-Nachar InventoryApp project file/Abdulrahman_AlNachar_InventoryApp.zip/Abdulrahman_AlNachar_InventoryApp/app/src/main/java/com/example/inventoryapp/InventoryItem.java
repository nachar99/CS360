// Just a simple model class for an inventory item
package com.example.inventoryapp;

public class InventoryItem {
    private int id;
    private String name;
    private int quantity;

    // when creating an item we pass in ID, name, and quantity
    public InventoryItem(int id, String name, int quantity) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
    }

    // returns the ID for this item
    public int getId() {
        return id;
    }

    // returns the name (label) of the item
    public String getName() {
        return name;
    }

    // returns how many units of this item we have
    public int getQuantity() {
        return quantity;
    }
}
